function reveal(obj, offsetTop){
    if(window.pageYOffset > offsetTop){
        obj.className += " up";
    }
}

// var el1 = document.getElementsByClassName('content')[0];
var el2 = document.getElementsByClassName('content')[1];
var el3 = document.getElementsByClassName('content')[2];
var el4 = document.getElementsByClassName('content')[3];

window.onscroll=function(){
    // reveal(el1, -1);
    reveal(el2, 650);
    reveal(el3, 1550);
    reveal(el4, 2285);
}
